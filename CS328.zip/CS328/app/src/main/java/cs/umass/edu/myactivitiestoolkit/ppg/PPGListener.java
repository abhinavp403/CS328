package cs.umass.edu.myactivitiestoolkit.ppg;

/**
 *
 */
public interface PPGListener {
    void onSensorChanged(PPGEvent event);
}

